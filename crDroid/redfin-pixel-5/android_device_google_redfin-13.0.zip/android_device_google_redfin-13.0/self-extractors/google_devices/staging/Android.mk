#
# Copyright (C) 2020 The Android Open-Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

LOCAL_PATH := $(call my-dir)

$(call declare-license-metadata,$(LOCAL_PATH)/vendor.img,legacy_proprietary,proprietary,$(LOCAL_PATH)/../LICENSE,"Vendor Image",vendor)

ifneq ($(filter redfin,$(TARGET_DEVICE)),)
  $(call add-radio-file,bootloader.img)
  $(call declare-license-metadata,$(LOCAL_PATH)/bootloader.img,legacy_proprietary,proprietary,$(LOCAL_PATH)/../LICENSE,"Vendor Bootloader Image",vendor)
  $(call add-radio-file,radio.img)
  $(call declare-license-metadata,$(LOCAL_PATH)/radio.img,legacy_proprietary,proprietary,$(LOCAL_PATH)/../LICENSE,"Vendor Radio Image",vendor)
endif
